// Package templates deals with creating template assets that will be used by other assets
package templates
