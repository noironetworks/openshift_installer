// Package destroy contains tools for destroying clusters based on their metadata.
package destroy
