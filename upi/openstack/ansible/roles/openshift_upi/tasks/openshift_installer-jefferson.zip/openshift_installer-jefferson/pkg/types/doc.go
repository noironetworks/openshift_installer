// Package types defines structures for installer configuration and
// management.
package types
