// Package baremetal provides a cluster-destroyer for bare metal clusters.
package baremetal
