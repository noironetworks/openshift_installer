// Package rhcos contains helpers for RHCOS related operations.
package rhcos
