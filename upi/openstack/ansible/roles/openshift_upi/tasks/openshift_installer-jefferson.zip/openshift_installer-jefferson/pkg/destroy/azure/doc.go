// Package azure provides a cluster-destroyer for Azure clusters.
package azure
