// Package vsphere provides a cluster-destroyer for vsphere clusters
package vsphere
