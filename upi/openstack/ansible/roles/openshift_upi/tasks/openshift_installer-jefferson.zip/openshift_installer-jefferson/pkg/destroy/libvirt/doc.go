// Package libvirt provides a cluster-destroyer for libvirt clusters.
package libvirt
