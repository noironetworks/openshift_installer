package none

// Platform stores any global configuration used for generic
// platforms.
type Platform struct{}
