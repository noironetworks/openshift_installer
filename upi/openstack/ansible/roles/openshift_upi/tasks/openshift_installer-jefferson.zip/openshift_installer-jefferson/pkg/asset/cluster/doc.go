// Package cluster contains asset targets that generates the terraform file,
// prepare the infra, and bootstrap the cluster.
package cluster
