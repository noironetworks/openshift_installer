// Package libvirt contains libvirt-specific structures for
// installer configuration and management.
package libvirt

// Name is the name for the libvirt platform.
const Name string = "libvirt"
