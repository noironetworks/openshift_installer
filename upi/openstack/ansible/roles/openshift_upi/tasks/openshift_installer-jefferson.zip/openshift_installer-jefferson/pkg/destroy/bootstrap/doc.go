// Package bootstrap provides a cluster-destroyer for Bootstrap node
package bootstrap
