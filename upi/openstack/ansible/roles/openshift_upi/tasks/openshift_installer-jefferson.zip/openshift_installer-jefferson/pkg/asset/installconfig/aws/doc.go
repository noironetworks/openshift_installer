// Package aws collects AWS-specific configuration.
package aws
