// Package azure contains Azure-specific structures for installer
// configuration and management.
package azure

// Name is name for the Azure platform.
const Name string = "azure"
