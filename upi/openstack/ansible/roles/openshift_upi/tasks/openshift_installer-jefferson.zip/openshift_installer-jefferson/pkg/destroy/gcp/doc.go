// Package gcp provides a cluster-destroyer for GCP clusters.
package gcp
