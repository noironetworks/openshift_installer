oVirt needs the same assets during setup except for ironic.
Please refer to https://github.com/openshift/installer/tree/master/data/data/bootstrap/baremetal
