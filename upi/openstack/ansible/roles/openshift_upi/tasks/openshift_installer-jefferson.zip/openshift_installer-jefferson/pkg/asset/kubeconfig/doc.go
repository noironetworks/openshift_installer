// Package kubeconfig defines and generates the kubeconfig assets.
package kubeconfig
