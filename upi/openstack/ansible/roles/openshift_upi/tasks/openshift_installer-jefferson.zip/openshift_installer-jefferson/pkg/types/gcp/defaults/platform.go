package defaults

import "github.com/openshift/installer/pkg/types/gcp"

// SetPlatformDefaults sets the defaults for the platform.
func SetPlatformDefaults(p *gcp.Platform) {
}
