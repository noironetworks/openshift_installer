// Package none contains generic structures for installer
// configuration and management.
package none

// Name is name for the None platform.
const Name string = "none"
