// Package aws provides a cluster-destroyer for AWS clusters.
package aws
