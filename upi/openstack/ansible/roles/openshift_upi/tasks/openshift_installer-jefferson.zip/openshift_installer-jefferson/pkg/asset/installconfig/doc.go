// Package installconfig generates the install config assets based on its dependencies.
// The type itself is defined in ../pkg/types.
package installconfig
