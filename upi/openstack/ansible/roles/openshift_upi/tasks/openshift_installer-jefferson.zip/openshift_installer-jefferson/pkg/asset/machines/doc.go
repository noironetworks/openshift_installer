// Package machines is responsible for creating Machine objects for machinepools.
package machines
