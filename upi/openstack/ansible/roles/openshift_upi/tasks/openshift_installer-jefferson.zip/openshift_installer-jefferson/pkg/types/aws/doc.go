// Package aws contains AWS-specific structures for installer
// configuration and management.
package aws

// Name is name for the AWS platform.
const Name string = "aws"
