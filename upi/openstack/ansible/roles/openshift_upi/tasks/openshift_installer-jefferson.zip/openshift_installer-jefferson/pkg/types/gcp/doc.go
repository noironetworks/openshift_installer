// Package gcp contains GCP-specific structures for installer
// configuration and management.
package gcp

// Name is name for the gcp platform.
const Name string = "gcp"
