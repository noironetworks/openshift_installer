// Package openstack provides a cluster-destroyer for openstack clusters.
package openstack
