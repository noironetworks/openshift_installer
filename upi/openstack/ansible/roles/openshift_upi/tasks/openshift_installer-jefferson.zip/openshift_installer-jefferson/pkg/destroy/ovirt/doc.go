// Package ovirt provides a cluster-destroyer for ovirt clusters.
package ovirt
